from flask import Flask, render_template, request, redirect, session
import random
app = Flask(__name__)
app.secret_key='thekey'

@app.route('/')
def entry():
    session['number'] = random.randrange(0,101)
    return render_template('index.html')
@app.route('/game')
def game():
    if int(session['guess']) !== int(session['number']):
        return redirect('/')
    else:
        return render_template('index2.html')



if __name__=="__main__":
    app.run(debug=True)