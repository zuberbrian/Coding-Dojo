from flask import Flask, render_template
app = Flask(__name__)

@app.route('/play')
def boxes():
    return render_template('index.html') * 3

@app.route('/play/<x>')
def multiple(x):
    return render_template('index.html', times=int(x)-1)
if __name__=="__main__":
    app.run(debug=True)